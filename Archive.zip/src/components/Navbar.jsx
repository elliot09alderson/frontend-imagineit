import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 w-full z-50 px-10 py-6 flex justify-between items-center mix-blend-difference text-white">
      <Link to="/" className="text-2xl font-serif font-bold tracking-tighter">
        ART.AI
      </Link>
      <div className="flex gap-8 font-sans text-sm uppercase tracking-widest">
        <Link to="/" className="hover:opacity-50 transition-opacity">Home</Link>
        <Link to="/community" className="hover:opacity-50 transition-opacity">Community</Link>
        <Link to="/edit" className="hover:opacity-50 transition-opacity">Create</Link>
      </div>
    </nav>
  );
};

export default Navbar;
