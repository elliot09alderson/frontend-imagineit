import React, { useEffect, useRef } from 'react';
import LocomotiveScroll from 'locomotive-scroll';
import { motion } from 'framer-motion';

const CommunityPage = () => {
  const scrollRef = useRef(null);

  useEffect(() => {
    const scroll = new LocomotiveScroll({
      el: scrollRef.current,
      smooth: true,
      multiplier: 1,
    });

    // Update scroll on image load
    const images = document.querySelectorAll('img');
    images.forEach(img => {
      if (img.complete) {
        scroll.update();
      } else {
        img.addEventListener('load', () => scroll.update());
      }
    });

    // ResizeObserver
    const resizeObserver = new ResizeObserver(() => scroll.update());
    resizeObserver.observe(scrollRef.current);

    return () => {
      if (scroll) scroll.destroy();
      resizeObserver.disconnect();
    };
  }, []);

  const images = [
    "https://images.unsplash.com/photo-1549490349-8643362247b5?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1561214115-f2f134cc4912?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1536924940846-227afb31e2a5?q=80&w=1000&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1515405295579-ba7b45403062?q=80&w=1000&auto=format&fit=crop",
  ];

  return (
    <div data-scroll-container ref={scrollRef} className="bg-art-black min-h-screen text-white pt-24 px-4 md:px-10">
      
      <div className="mb-20 text-center" data-scroll-section>
        <motion.h1 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-6xl md:text-9xl font-serif font-bold mb-6"
        >
            COMMUNITY
        </motion.h1>
        <p className="text-xl text-gray-400 font-sans tracking-widest uppercase">
            Explore creations by artists worldwide
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 pb-20" data-scroll-section>
        {images.map((src, index) => (
            <div 
                key={index} 
                className={`relative overflow-hidden aspect-[3/4] ${index % 2 === 0 ? 'mt-0' : 'mt-20'}`}
                data-scroll
                data-scroll-speed={index % 2 === 0 ? "1" : "2"}
            >
                <motion.div
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.5 }}
                    className="w-full h-full"
                >
                    <img 
                        src={src} 
                        alt={`Community Art ${index}`} 
                        className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-500"
                    />
                    <div className="absolute bottom-0 left-0 p-6 bg-gradient-to-t from-black/80 to-transparent w-full opacity-0 hover:opacity-100 transition-opacity duration-300">
                        <h3 className="text-xl font-serif">Artistic Vision #{index + 1}</h3>
                        <p className="text-sm text-gray-300">@artist_name</p>
                    </div>
                </motion.div>
            </div>
        ))}
      </div>

      <section className="py-20 text-center" data-scroll-section>
        <h2 className="text-4xl font-serif mb-8">Join the Movement</h2>
        <button className="px-8 py-3 border border-white rounded-full hover:bg-white hover:text-black transition-colors duration-300 uppercase tracking-widest text-sm">
            Upload Your Art
        </button>
      </section>

    </div>
  );
};

export default CommunityPage;
