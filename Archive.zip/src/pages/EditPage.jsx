import React from 'react';

const EditPage = () => {
  return (
    <div className="min-h-screen bg-art-black text-white flex items-center justify-center pt-20">
      <h1 className="text-4xl font-serif text-gray-500">Editor Coming Soon...</h1>
    </div>
  );
};

export default EditPage;
